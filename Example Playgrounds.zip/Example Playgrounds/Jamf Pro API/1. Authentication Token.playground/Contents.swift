//This playground retrieves a athentication token from Jamf Pro
//Just complete the three constants with the required details
import Cocoa

let jamfUser = ""
let jamfPassword = ""
let jamfURL = "https://"

//Structure to hold the returned token
struct JamfProAuth: Decodable {
    let token: String
    let expires: String
}

//This function generates the base64 from a user namd and password
func encodeBase64(user: String, password: String) -> String? {
    let authString = user + ":" + password
    let encoded = authString.data(using: .utf8)?.base64EncodedString()
    return encoded
}

//This function queries the Jamf Pro API for a authentication token
func getToken(jamfURL: String, base64: String ) {
    let tokenURLString = jamfURL + "/api/v1/auth/token"

    let url = URL(string: tokenURLString)!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.setValue("Basic \(base64)", forHTTPHeaderField: "Authorization")
    request.setValue("application/json", forHTTPHeaderField: "Accept")

    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
        if let error = error {
            //handle error
        } else if (response as? HTTPURLResponse)?.statusCode != 200 {
            //handle error
        } else {
            if let data = data {
                if let auth = try? JSONDecoder().decode(JamfProAuth.self, from: data) {
                    print("We have a token")
                    print("Token: \(auth.token)")
                    print("Expires: \(auth.expires)")
                }
            }
        }
    }
    task.resume()

}


//Entry Point
if let base64UserPassword = encodeBase64(user: jamfUser, password: jamfPassword) {
    getToken(jamfURL: jamfURL, base64: base64UserPassword)
}

    
    

