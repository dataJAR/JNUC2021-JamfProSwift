//This playground retrieves a athentication token from Jamf Pro then renews it
//Just complete the three constants with the required details
import Cocoa

let jamfUser = ""
let jamfPassword = ""
let jamfURL = "https://"

//Structure to hold the returned token
struct JamfProAuth: Decodable {
    let token: String
    let expires: String
}

//varaiable to hold the authentication token
var authtToken = ""


//This function generates the base64 from a user name and password
func encodeBase64(user: String, password: String) -> String? {
    let authString = user + ":" + password
    let encoded = authString.data(using: .utf8)?.base64EncodedString()
    return encoded
}



//This function queries the Jamf Pro API for a authentication token
//Once receieved it then renews the token
func getToken(jamfURL: String, base64: String ) {
    let tokenURLString = jamfURL + "/api/v1/auth/token"

    let url = URL(string: tokenURLString)!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.setValue("Basic \(base64)", forHTTPHeaderField: "Authorization")
    request.setValue("application/json", forHTTPHeaderField: "Accept")

    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
        if let error = error {
            //handle error
        } else if (response as? HTTPURLResponse)?.statusCode != 200 {
            //handle error
        } else {
            if let data = data {
                if let auth = try? JSONDecoder().decode(JamfProAuth.self, from: data) {
                    print("We have a token")
                    print("Token: \(auth.token)")
                    print("Expires: \(auth.expires)")
                    authtToken = auth.token
                    renewToken(jamfURL: jamfURL)
                }
            }
        }
    }
    task.resume()

}

//This function renews the current authentication token
func renewToken(jamfURL: String)  {
    let tokenURLString = jamfURL + "/api/v1/auth/keep-alive"

    let url = URL(string: tokenURLString)!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.setValue("Bearer \(authtToken)", forHTTPHeaderField: "Authorization")
    request.setValue("application/json", forHTTPHeaderField: "Accept")

    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
        if let httpResponse = response as? HTTPURLResponse  {
            if let error = error {
                //handle error
            } else if (response as? HTTPURLResponse)?.statusCode != 200 {
                //handle error
            } else {
                if let data = data {
                    if let auth = try? JSONDecoder().decode(JamfProAuth.self, from: data) {
                        print("We have renewed the token")
                        print("New Token: \(auth.token)")
                        print("New Expires: \(auth.expires)")
                        authtToken = auth.token
                    } else {
                        print("Failed to decode")
                    }
                }
            }
        }
    }
    task.resume()
}


//Entry Point
if let base64UserPassword = encodeBase64(user: jamfUser, password: jamfPassword) {
    getToken(jamfURL: jamfURL, base64: base64UserPassword)
}

