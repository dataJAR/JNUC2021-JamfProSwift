//This playground retrieves a list of computers assigned to a specified prestage
//Just complete the four constants with the required details including the id of a valid computer pre-stage
import Cocoa

let jamfUser = ""
let jamfPassword = ""
let jamfURL = "https://"
let computerPrestageID = "2"

//Structure to hold the auth token
struct JamfProAuth: Decodable {
    let token: String
    let expires: String
}

//Struct to hold the returned details for our computer prestage
struct ComputerPrestageCurrentScope: Codable {
    let prestageId: String
    let assignments: [ComputerPreStsgeScopeAssignment]
    let versionLock: Int
}

// MARK: - Assignment
struct ComputerPreStsgeScopeAssignment: Codable {
    let serialNumber: String
    let assignmentDate: String // assignmentDate and String
    let userAssigned: String
}


//This function generates the base64 from a user namd and password
func encodeBase64(user: String, password: String) -> String? {
    let authString = user + ":" + password
    let encoded = authString.data(using: .utf8)?.base64EncodedString()
    return encoded
}


var depVersionLock = 0
var authToken = ""

//Function to get the details for the specitfied computer pre-stage
func getPrestageAssignments(jamfURL: String, computerPrestageID: String) {
    let jamfURLQuery = jamfURL + "/api/v2/computer-prestages/" + computerPrestageID + "/scope"
    let url = URL(string: jamfURLQuery)!
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.setValue("Bearer \(authToken)", forHTTPHeaderField: "Authorization")
    request.setValue("application/json", forHTTPHeaderField: "Accept")

    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
        if let error = error {
            //handle error
        } else if (response as? HTTPURLResponse)?.statusCode != 200 {
            //handle error
        } else {
            if let data = data {
                let decoder = JSONDecoder()
                if let currentScope = try? JSONDecoder().decode(ComputerPrestageCurrentScope.self, from: data) {
                    print(currentScope)
                }
            }
        }
    }
    task.resume()
}


//Function to get the authentication token
func getToken(jamfURL: String, base64: String ) {
    let tokenURLString = jamfURL + "/api/v1/auth/token"

    let url = URL(string: tokenURLString)!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.setValue("Basic \(base64)", forHTTPHeaderField: "Authorization")
    request.setValue("application/json", forHTTPHeaderField: "Accept")

    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
        if let error = error {
            //handle error
        } else if (response as? HTTPURLResponse)?.statusCode != 200 {
            //handle error
        } else {
            if let data = data {
                if let auth = try? JSONDecoder().decode(JamfProAuth.self, from: data) {
                    print("We have a token")
                    print("Token: \(auth.token)")
                    print("Expires: \(auth.expires)")
                    authToken = auth.token
                    getPrestageAssignments(jamfURL: jamfURL, computerPrestageID: computerPrestageID)
                }
            }
        }
    }
    task.resume()

}




//Entry Point
//We first call the function to get an authentication token
//Which then calls the function to query the specified computer-prestage
if let base64UserPassword = encodeBase64(user: jamfUser, password: jamfPassword) {
    getToken(jamfURL: jamfURL, base64: base64UserPassword)
}

    
    

