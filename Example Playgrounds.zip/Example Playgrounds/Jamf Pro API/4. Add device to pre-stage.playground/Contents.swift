//This playground adds a computer to aspecified prestage
//Just complete the five constants with the required details including the ID of the valid computer pre-stage
//and the serial number of te computer to add to the prestage
import Cocoa


let jamfUser = ""
let jamfPassword = ""
let jamfURL = "https://"
let computerPrestageID = "2"
let computerSerialNumber = "xxxxxxxx"

struct JamfProAuth: Decodable {
    let token: String
    let expires: String
}

struct ComputerPrestageCurrentScope: Codable {
    let sprestageID: String //String
    let assignments: [ComputerPreStsgeScopeAssignment]
    let versionLock: Int
    
    enum CodingKeys: String, CodingKey {
        case sprestageID = "prestageId"
        case assignments, versionLock
    }
    var prestageID: Int { return Int(sprestageID) ?? 0 }

}

// MARK: - Assignment
struct ComputerPreStsgeScopeAssignment: Codable {
    let serialNumber: String
    let assignmentDate: String // assignmentDate and String
    let userAssigned: String
    

}


//This function generates the base64 from a user name and password
func encodeBase64(user: String, password: String) -> String? {
    let authString = user + ":" + password
    let encoded = authString.data(using: .utf8)?.base64EncodedString()
    return encoded
}



var depVersionLock = 0
var authToken = ""


//Function to add the computer to the specified computer pre-stage
func addDeviceToPrestage(jamfURL: String, computerPrestageID: String, serial: String) {
    let jamfURLQuery = jamfURL + "/api/v2/computer-prestages/" + computerPrestageID + "/scope"
    let url = URL(string: jamfURLQuery)!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.setValue("Bearer \(authToken)", forHTTPHeaderField: "Authorization")
    request.setValue("application/json", forHTTPHeaderField: "Accept")
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    
    let json: [String: Any] = ["serialNumbers": [serial],
                               "versionLock": depVersionLock]

    let jsonData = try? JSONSerialization.data(withJSONObject: json)
    if let jsonData = jsonData {
        
        request.httpBody = jsonData
        
    }
    
    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
        if let error = error {
            //handle error
        } else if (response as? HTTPURLResponse)?.statusCode != 200 {
            //handle error
        } else {
            print("We updated the prestage")
        }
    }
    task.resume()

}


//Function to thet the details of the specified computer pre-stage
func getPrestageAssignments(jamfURL: String, computerPrestageID: String) {
    let jamfURLQuery = jamfURL + "/api/v2/computer-prestages/" + computerPrestageID + "/scope"
    let url = URL(string: jamfURLQuery)!
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.setValue("Bearer \(authToken)", forHTTPHeaderField: "Authorization")
    request.setValue("application/json", forHTTPHeaderField: "Accept")

    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
        if let error = error {
            //handle error
        } else if (response as? HTTPURLResponse)?.statusCode != 200 {
            //handle error
        } else {
            if let data = data {
                let decoder = JSONDecoder()
                if let currentScope = try? JSONDecoder().decode(ComputerPrestageCurrentScope.self, from: data) {
                    print(currentScope)
                    depVersionLock = currentScope.versionLock
                    addDeviceToPrestage(jamfURL: jamfURL, computerPrestageID: computerPrestageID, serial: computerSerialNumber)
                }
            }
        }
    }
    task.resume()
}

//Function to get the authentication token
func getToken(jamfURL: String, base64: String ) {
    let tokenURLString = jamfURL + "/api/v1/auth/token"

    let url = URL(string: tokenURLString)!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.setValue("Basic \(base64)", forHTTPHeaderField: "Authorization")
    request.setValue("application/json", forHTTPHeaderField: "Accept")

    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
        if let error = error {
            //handle error
        } else if (response as? HTTPURLResponse)?.statusCode != 200 {
            //handle error
        } else {
            if let data = data {
                if let auth = try? JSONDecoder().decode(JamfProAuth.self, from: data) {
                    print("We have a token")
                    print("Token: \(auth.token)")
                    print("Expires: \(auth.expires)")
                    authToken = auth.token
                    getPrestageAssignments(jamfURL: jamfURL, computerPrestageID: computerPrestageID)
                }
            }
        }
    }
    task.resume()

}




//Entry Point
//We first call the function to get an auth token
//We then get the details for the prestage, specifically we need the version lock attribute
//We then add the computer to that pre-stage
if let base64UserPassword = encodeBase64(user: jamfUser, password: jamfPassword) {
    getToken(jamfURL: jamfURL, base64: base64UserPassword)
}

    

