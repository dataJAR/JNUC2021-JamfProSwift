//This playground sends the MDM command "Enable Bluetooth" to a specific mobile device
//Just complete the four constants with the required details including the ID of a valid mobile device record in Jamf

import Cocoa

let jamfUser = ""
let jamfPassword = ""
let jamfURL = "https://"
let mobileDeviceID = "8"


//This function generates the base64 from a user name and password
func encodeBase64(user: String, password: String) -> String? {
    let authString = user + ":" + password
    let encoded = authString.data(using: .utf8)?.base64EncodedString()
    return encoded
}

//This function sends an mdm command to enable bluetooth for the specific mobile device
func enableBluetooth(jamfURL: String, base64: String, mobileDeviceID: String) {
    let jamfURLQuery = jamfURL + "/JSSResource/mobiledevicecommands/command/" + "SettingsEnableBluetooth" + "/id/" + mobileDeviceID
    let url = URL(string: jamfURLQuery)!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.setValue("Basic \(base64)", forHTTPHeaderField: "Authorization")
    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
        if let error = error {
            print(error.localizedDescription)
            //handle error
        } else if (response as? HTTPURLResponse)?.statusCode != 201 {
            //handle error
        } else {
            print("Bluetooth mdm command was sent")
        }
    }
    task.resume()
}


//Entry Point
if let base64UserPassword = encodeBase64(user: jamfUser, password: jamfPassword) {
    enableBluetooth(jamfURL: jamfURL, base64: base64UserPassword, mobileDeviceID: mobileDeviceID)
}




