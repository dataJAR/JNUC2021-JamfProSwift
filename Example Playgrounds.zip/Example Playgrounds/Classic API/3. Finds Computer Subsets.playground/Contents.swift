//This playground queries Jamf Pro for a specific computer with the subsets of general, location, hardware
//Just complete the four constants with the required details including the ID of a valid computer record in Jamf

import Cocoa

let jamfUser = ""
let jamfPassword = ""
let jamfURL = "https://"
let computerID = "30"


//Structure to hold the data for the specified computer.
//For each subet we specify the attributes we are interested in.
struct Subset: Codable {
    let computer: Computer
}

struct Computer: Codable {
    let general: General
    let location: Location
    let hardware: Hardware
}

struct General: Codable {
    let id: Int
    let name, macAddress, serialNumber, lastContactTime: String

    enum CodingKeys: String, CodingKey {
        case id, name
        case macAddress = "mac_address"
        case serialNumber = "serial_number"
        case lastContactTime = "last_contact_time"
    }
}

struct Hardware: Codable {
    let model, osVersion: String

    enum CodingKeys: String, CodingKey {
        case model
        case osVersion = "os_version"
    }
}

struct Location: Codable {
    let username, realname, realName, emailAddress: String

    enum CodingKeys: String, CodingKey {
        case username, realname
        case realName = "real_name"
        case emailAddress = "email_address"
    }
}



//This function generates the base64 from a user name and password
func encodeBase64(user: String, password: String) -> String? {
    let authString = user + ":" + password
    let encoded = authString.data(using: .utf8)?.base64EncodedString()
    return encoded
}

//Function that queries a specific computer via its ID
//The subset is set to general, location and hardware
func getComputer(jamfURL: String, base64: String, computerID: String) {
    let jamfURLQuery = jamfURL + "/JSSResource/computers/id/" + computerID + "/subset/general&location&hardware"
    let url = URL(string: jamfURLQuery)!
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.setValue("Basic \(base64)", forHTTPHeaderField: "Authorization")
    request.setValue("application/json", forHTTPHeaderField: "Accept")
    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
        if let error = error {
            //handle errror
        } else if (response as? HTTPURLResponse)?.statusCode != 200 {
            //handle error
        } else {
            if let data = data {
                let decoder = JSONDecoder()
                if let subset = try? decoder.decode(Subset.self, from: data) {
                    //Handle data
                    print(subset.computer.general)
                    print(subset.computer.location)
                    print(subset.computer.hardware)
                }
            }
        }
    }
    task.resume()
}


//Entry Point
//We generate our base 64 then call the function to get subsets for the specific computer
if let base64UserPassword = encodeBase64(user: jamfUser , password: jamfPassword) {
    getComputer(jamfURL: jamfURL, base64: base64UserPassword, computerID: computerID)
}


