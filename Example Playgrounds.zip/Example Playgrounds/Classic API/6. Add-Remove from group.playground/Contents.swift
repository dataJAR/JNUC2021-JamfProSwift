//This playground adds or removes a mobile device from a specified static group
//Just complete the five constants with the required details including the name of a valid static mobioe group in Jamf
import Cocoa

let jamfUser = ""
let jamfPassword = ""
let jamfURL = "https://"
let mobileDeviceID = "8"
let groupName = "VIPs"


//This function generates the base64 from a user namd and password
func encodeBase64(user: String, password: String) -> String? {
    let authString = user + ":" + password
    let encoded = authString.data(using: .utf8)?.base64EncodedString()
    return encoded
}

//Function to either add or remove a mobile device from a static group
func modifyGroup(jamfURL: String, base64: String, mobileDeviceID: String, groupName: String, addToGroup: Bool) {
    let jamfURLQuery = jamfURL + "/JSSResource/mobiledevicegroups/name/" + groupName
    var httpBody = ""
    
    if addToGroup {
        httpBody  += "<mobile_device_group><mobile_device_additions><mobile_device><id>\(mobileDeviceID)</id></mobile_device></mobile_device_additions></mobile_device_group>"
    } else {
        httpBody  += "<mobile_device_group><mobile_device_deletions><mobile_device><id>\(mobileDeviceID)</id></mobile_device></mobile_device_deletions></mobile_device_group>"
    }
    
    let url = URL(string: jamfURLQuery)!
    var request = URLRequest(url: url)
    request.httpMethod = "PUT"
    request.setValue("Basic \(base64)", forHTTPHeaderField: "Authorization")
    request.httpBody = httpBody.data(using: String.Encoding.utf8)

    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
        if let error = error {
            //handle error
        } else if (response as? HTTPURLResponse)?.statusCode != 201 {
            //handle error
        } else {
            print("Group Edit command was sent")
        }
    }
    task.resume()
}





//Entry Point
if let base64UserPassword = encodeBase64(user: jamfUser, password: jamfPassword) {
    modifyGroup(jamfURL: jamfURL, base64: base64UserPassword, mobileDeviceID: mobileDeviceID, groupName: groupName, addToGroup: true)
}

    
