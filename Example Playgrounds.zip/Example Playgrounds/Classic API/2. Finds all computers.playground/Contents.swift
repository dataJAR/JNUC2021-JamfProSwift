//This playground queries Jamf Pro for a list of computers
//Just complete the three constants with the required details

import Cocoa


let jamfUser = ""
let jamfPassword = ""
let jamfURL = "https://"


//Sructure to hold the list of computers returned
struct AllComputers: Codable {
    let computers: [Computer]
}


struct Computer: Codable {
    let id: Int
    let name: String
}


//This function generates the base64 from a user name and password
func encodeBase64(user: String, password: String) -> String? {
    let authString = user + ":" + password
    let encoded = authString.data(using: .utf8)?.base64EncodedString()
    return encoded
}


//This function makes the connection to Jamf Pro for the list of computers
//Requests the returned data as json
func getComputers(jamfURL: String, base64: String) {
    let jamfURLQuery = jamfURL + "/JSSResource/computers"
    let url = URL(string: jamfURLQuery)!
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.setValue("Basic \(base64)", forHTTPHeaderField: "Authorization")
    request.setValue("application/json", forHTTPHeaderField: "Accept")
    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
        guard error == nil && (response as? HTTPURLResponse)?.statusCode == 200 else {
                print("Connection Failure")
            return
        }
        print("Connection Success")
        if let data = data {
            let decoder = JSONDecoder()
            if let allComputers = try? decoder.decode(AllComputers.self, from: data) {
                //We have some data that we can handle
                print("The following computers where found")
                for computer in allComputers.computers {
                    print("id: \(computer.id) name: \(computer.name)")
                }
            }
        }
    }
    task.resume()
}


//Entry Point
//We generate our base 64 then call the function to get the list of computers
if let base64UserPassword = encodeBase64(user: jamfUser, password: jamfPassword) {
    print(base64UserPassword)
    getComputers(jamfURL: jamfURL, base64: base64UserPassword)
}


