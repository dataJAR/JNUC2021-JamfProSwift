//This playground generates base64 from a username and password
//Just complete the two constants with the required details


import Cocoa

let jamfUser = ""
let jamfPassword = ""


//This function generates the base64 from a user name and password
func encodeBase64(user: String, password: String) -> String? {
    let authString = user + ":" + password
    let encoded = authString.data(using: .utf8)?.base64EncodedString()
    return encoded
}

//This function can check if any base64 is valid
func isBase64(stringToTest: String) -> Bool {
    if let _ = Data(base64Encoded: stringToTest) {
        return true
    } else {
        return false
    }
}


//Entry Point
//if let is used as the encodeBase64 function returns an optional
if let base64UserPassword = encodeBase64(user: jamfUser, password: jamfPassword) {
    print("The encoded username and password is \(base64UserPassword)")
    if isBase64(stringToTest: base64UserPassword) {
        print("The base64 is valid")
    }
}


