//This playground sends the MDM command "Enable Lost Mode" to a specific mobile device
//Just complete the four constants with the required details including the ID of a valid mobile device record in Jamf
import Cocoa

let jamfUser = ""
let jamfPassword = ""
let jamfURL = "https://"
let mobileDeviceID = "8"


//This function generates the base64 from a user name and password
func encodeBase64(user: String, password: String) -> String? {
    let authString = user + ":" + password
    let encoded = authString.data(using: .utf8)?.base64EncodedString()
    return encoded
}

//This function sends the lost mode command. You can specify the message shown to the user
//and whether you want the lost mode sound played
func enableLostMode(jamfURL: String, base64: String, mobileDeviceID: String, message: String, playSound: Bool) {
    let jamfURLQuery = jamfURL + "/JSSResource/mobiledevicecommands/command/EnableLostMode"
    let httpBody =  "<mobile_device_command><command>EnableLostMode</command><lost_mode_message>\(message)</lost_mode_message><lost_mode_with_sound>\(String(playSound))</lost_mode_with_sound><mobile_devices><mobile_device><id>\(mobileDeviceID)</id></mobile_device></mobile_devices></mobile_device_command>"
    
    let url = URL(string: jamfURLQuery)!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.setValue("Basic \(base64)", forHTTPHeaderField: "Authorization")
    request.setValue("text/xml", forHTTPHeaderField: "Content-Type")
    request.httpBody = httpBody.data(using: String.Encoding.utf8)

    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
        if let error = error {
            //handle error
        } else if (response as? HTTPURLResponse)?.statusCode != 201 {
            //handle error
        } else {
            print("LostMode command successfully sent")
        }
    }
    task.resume()
}




//Entry Point
if let base64UserPassword = encodeBase64(user: jamfUser, password: jamfPassword) {
    let message = "If found please call xxx to return device"
    enableLostMode(jamfURL: jamfURL, base64: base64UserPassword, mobileDeviceID: mobileDeviceID, message: message, playSound: true)

}


